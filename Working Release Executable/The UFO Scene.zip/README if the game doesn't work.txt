1. Unzip the whole archive content.

2. Please try to access 'The UFO Scene' (.exe) file usign Right Mouse Button,
select "Run with graphics processor" and then "High performance ... processor".